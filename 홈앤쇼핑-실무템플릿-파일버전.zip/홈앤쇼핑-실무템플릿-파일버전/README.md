# 홈앤쇼핑 실무 템플릿 · 파일 버전 (구글시트 미사용)

> 시트 버전과 **동일한 10종 플로우**를 구글 크리덴셜 없이 돌리는 버전.
> Google Sheets 노드 대신 **Read/Write Files from Disk + Extract from File(CSV)** 를 씁니다.

## 시트 버전과 뭐가 다른가
| 시트 버전 | 파일 버전 |
|---|---|
| Google Sheets — Get Row(s) | **Read/Write Files from Disk**(읽기) → **Extract from File**(CSV 파싱) |
| Google Sheets — Append Row | **Convert to File**(CSV 변환) → **Read/Write Files from Disk**(쓰기, 날짜별 파일) |
| Google 크리덴셜 필요 | **크리덴셜 불필요** (파일 I/O) |
| 아카이브 = 시트에 행 누적 | 아카이브 = `이름_YYYY-MM-DD_HHmm.csv` **날짜별 파일 생성** |

## ★가장 중요한 한 가지 — 파일은 `~/.n8n-files/` 안에
n8n(self-host)은 보안상 **`~/.n8n-files/` 폴더 안의 파일만** 읽고 쓸 수 있습니다(실행으로 확인됨).
1. 홈 폴더에 `.n8n-files` 폴더 생성: 터미널에서 `mkdir -p ~/.n8n-files`
2. CSV 데이터 파일을 그 안에 넣기 (예: `방송예정상품.csv`)
3. 워크플로의 `YOUR_DATA_DIR`를 **본인 절대경로**로 교체
   - macOS: `/Users/본인계정/.n8n-files`
   - Windows: `C:\Users\본인계정\.n8n-files`
4. 다른 폴더를 쓰고 싶으면 n8n 시작 시 `N8N_RESTRICT_FILE_ACCESS_TO=/원하는/경로` 환경변수로 허용 경로 추가

> 🧰 **실전 막힘 카드**: CSV를 바탕화면에 두면 `Access to the file is not allowed` 에러가 납니다.
> 에러 전문을 **Claude Code에 붙여넣으면** (a) `~/.n8n-files`로 옮기기 또는 (b) `N8N_RESTRICT_FILE_ACCESS_TO=$HOME/Desktop` 재시작 중 하나로 풀어줍니다 — M6 디버깅 루프 그대로.

## 필요한 CSV (헤더는 시트 버전과 동일)
| 파일 | 헤더 |
|---|---|
| `방송예정상품.csv` | 상품명, 우리방송가 |
| `경쟁사편성.csv` | 채널, 시간, 상품, 카테고리 |
| `방송현황.csv` | 상품명, 목표매출, 총방송분, 경과분, 누적매출 |
| `방송결과.csv` | 방송명, 목표매출, 매출, 주문건수, 콜인입, 콜포기율, 반품건수 |
| `반품데이터.csv` | 상품명, 반품사유 |
| `발주현황.csv` | 협력사명, 담당자, 담당자메일, 상품명, 현재재고, 발주필요수량 |
| `내일편성.csv` | 방송명, 예상판매량, 현재재고, 가격설정여부, 혜택설정여부, 물량확정여부, 자막준비여부 |
| `콜현황.csv` | 진행중방송, 현재대기, 콜포기율, 상담원가동 |
| `카피요청.csv` | 상품명, 핵심특징, 가격 |

## 그 외는 시트 버전과 동일
- AI(★) 템플릿 = Header Auth `x-api-key` (회사 Anthropic 키), 모델 `claude-sonnet-5`
- 수신자 `YOUR_...@example.com` 교체 · import 후 노드별 Test step 검증
- ⚠️ 아카이브 파일명의 시각이 이상하면 n8n을 `GENERIC_TIMEZONE=Asia/Seoul`로 띄웠는지 확인
